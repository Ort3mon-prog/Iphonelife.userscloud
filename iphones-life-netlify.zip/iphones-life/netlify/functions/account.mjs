import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

// Прості акаунти: ім’я (латиниця) + пароль, прогрес гри зберігається в Netlify Blobs.
const J = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });
const hash = (p, salt) => crypto.scryptSync(p, salt, 32).toString("hex");
const NAME = /^[A-Za-z]{3,20}$/;

export default async (req) => {
  if (req.method !== "POST") return J({ ok: false, err: "method" }, 405);
  let b;
  try { b = await req.json(); } catch { return J({ ok: false, err: "bad" }, 400); }

  const name = String(b.name || "").trim();
  const pass = String(b.pass || "");
  const action = b.action;
  if (!NAME.test(name)) return J({ ok: false, err: action === "register" ? "badname" : "noname" });

  const store = getStore("accounts");
  const key = name.toLowerCase();
  const acc = await store.get(key, { type: "json" });

  if (action === "register") {
    if (acc) return J({ ok: false, err: "exists" });
    if (pass.length < 4 || pass.length > 64) return J({ ok: false, err: "badpw" });
    const salt = crypto.randomBytes(16).toString("hex");
    const rec = { name, salt, hash: hash(pass, salt), v: 1, t: Date.now(), data: typeof b.data === "string" ? b.data : null };
    await store.setJSON(key, rec);
    return J({ ok: true, name, v: 1 });
  }

  // Далі всі дії потребують існуючого акаунта: спочатку ім’я, потім пароль
  if (!acc) return J({ ok: false, err: "noname" });
  if (hash(pass, acc.salt) !== acc.hash) return J({ ok: false, err: "badpass" });

  if (action === "login" || action === "load") {
    return J({ ok: true, name: acc.name, v: acc.v, data: acc.data });
  }

  if (action === "save") {
    if (typeof b.data !== "string" || b.data.length > 4e6) return J({ ok: false, err: "bad" });
    if (!b.force && b.base !== acc.v) return J({ ok: false, err: "conflict", v: acc.v, data: acc.data });
    acc.data = b.data;
    acc.v = acc.v + 1;
    acc.t = Date.now();
    await store.setJSON(key, acc);
    return J({ ok: true, v: acc.v });
  }

  return J({ ok: false, err: "bad" }, 400);
};
